"""Windows GUI for the IGS ROM restoration tool."""

from __future__ import annotations

import json
import queue
import threading
import traceback
import webbrowser
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import dmnfrnt_restore as core


APP_VERSION = "1.1"
APP_TITLE = f"IGS ROM Restore {APP_VERSION}"
HOMEPAGE = "https://github.com/alhumbra/botuneta"

TEXT = {
    "en": {
        "tagline": "Automatically detect and convert supported ROM files by filename.",
        "language": "Language",
        "input_folder": "ROM input folder",
        "output_folder": "Output folder",
        "browse": "Browse...",
        "start": "Start conversion",
        "clear": "Clear log",
        "ready": "Select the input and output folders.",
        "choose_input": "Select the ROM input folder",
        "choose_output": "Select the output folder",
        "bad_input": "Select a valid ROM input folder.",
        "bad_output": "Select an output folder.",
        "same_folder": "Select different input and output folders.",
        "running": "Conversion in progress...",
        "input_log": "Input",
        "output_log": "Output",
        "pgm": "Restore PGM maincpu",
        "container": "Restore encrypted container",
        "complete": "Completed",
        "skip": "Skipped (unsupported)",
        "error": "Error",
        "report": "Report",
        "no_zip": "The input folder contains no .zip files.",
        "no_supported": "No supported ROM files were found.",
        "done_status": "Finished: {ok} converted, {failed} errors",
        "done_dialog": "Conversion finished.\nConverted: {ok}\nErrors: {failed}",
        "failed_status": "Conversion failed.",
        "author": "Author: alhumbra",
        "homepage": "Homepage:",
    },
    "ja": {
        "tagline": "ROM名から処理を自動判定して一括変換します。",
        "language": "言語",
        "input_folder": "ROM入力フォルダー",
        "output_folder": "出力フォルダー",
        "browse": "参照...",
        "start": "変換開始",
        "clear": "ログを消去",
        "ready": "入力・出力フォルダーを指定してください。",
        "choose_input": "ROM入力フォルダーを選択",
        "choose_output": "出力フォルダーを選択",
        "bad_input": "有効なROM入力フォルダーを指定してください。",
        "bad_output": "出力フォルダーを指定してください。",
        "same_folder": "入力と出力には別のフォルダーを指定してください。",
        "running": "変換中です...",
        "input_log": "入力",
        "output_log": "出力",
        "pgm": "PGM maincpu復元",
        "container": "独自コンテナ復元",
        "complete": "完了",
        "skip": "スキップ（対象外）",
        "error": "エラー",
        "report": "レポート",
        "no_zip": "入力フォルダーに .zip ファイルがありません。",
        "no_supported": "対応しているROMが見つかりませんでした。",
        "done_status": "完了: {ok}件変換、{failed}件エラー",
        "done_dialog": "変換が完了しました。\n成功: {ok}件\nエラー: {failed}件",
        "failed_status": "変換に失敗しました。",
        "author": "作者: alhumbra",
        "homepage": "ホームページ:",
    },
}


def convert_folder(input_dir: Path, output_dir: Path, log, strings=None) -> tuple[int, int]:
    strings = strings or TEXT["en"]
    output_dir.mkdir(parents=True, exist_ok=True)
    reports = []
    converted = 0
    failed = 0
    candidates = sorted(input_dir.glob("*.zip"))
    if not candidates:
        raise ValueError(strings["no_zip"])

    for source in candidates:
        lower = source.name.lower()
        try:
            profile = core.REFERENCE_FREE_PGM.get(lower)
            if profile is not None:
                output_name = profile.get("set_name", source.name)
                destination = output_dir / output_name
                log(f"{strings['pgm']}: {source.name}")
                report = core.restore_reference_free_pgm_zip(source, destination)
                report["type"] = "pgm-maincpu"
                reports.append(report)
                log(f"  {strings['complete']}: {destination.name}")
                converted += 1
                continue

            if lower in {"dmnfrnt.zip", "theglad.zip"} and not zipfile.is_zipfile(source):
                destination = output_dir / f"{source.stem}-restored.zip"
                log(f"{strings['container']}: {source.name}")
                raw = core.decrypt_and_inflate(source)
                manifest = core.build_zip(raw, destination, None)
                reports.append({
                    "source": str(source), "output": str(destination),
                    "type": "encrypted-container", "raw_sha256": manifest["raw_sha256"],
                })
                log(f"  {strings['complete']}: {destination.name}")
                converted += 1
                continue

            log(f"{strings['skip']}: {source.name}")
        except Exception as exc:
            failed += 1
            log(f"{strings['error']}: {source.name}: {exc}")
            reports.append({"source": str(source), "error": str(exc)})

    report_path = output_dir / "conversion-report.json"
    report_path.write_text(json.dumps(reports, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    log(f"{strings['report']}: {report_path.name}")
    if converted == 0 and failed == 0:
        raise ValueError(strings["no_supported"])
    return converted, failed


class RestoreApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("760x520")
        self.root.minsize(680, 430)
        self.messages: queue.Queue[tuple[str, object]] = queue.Queue()
        self.language_var = tk.StringVar(value="English")
        self.language = "en"
        self.input_var = tk.StringVar()
        self.output_var = tk.StringVar()
        self.status_var = tk.StringVar()
        self._build()
        self._set_language()
        self.root.after(100, self._poll)

    def _build(self):
        frame = ttk.Frame(self.root, padding=16)
        frame.pack(fill="both", expand=True)
        header = ttk.Frame(frame)
        header.pack(fill="x")
        ttk.Label(header, text=APP_TITLE, font=("Yu Gothic UI", 16, "bold")).pack(side="left")
        self.language_label = ttk.Label(header)
        self.language_label.pack(side="right", padx=(8, 4))
        self.language_box = ttk.Combobox(
            header, textvariable=self.language_var, values=("English", "日本語"),
            state="readonly", width=10,
        )
        self.language_box.pack(side="right")
        self.language_box.bind("<<ComboboxSelected>>", self._set_language)
        self.tagline_label = ttk.Label(frame)
        self.tagline_label.pack(anchor="w", pady=(2, 4))

        identity = ttk.Frame(frame)
        identity.pack(fill="x", pady=(0, 16))
        self.author_label = ttk.Label(identity, font=("Yu Gothic UI", 9, "bold"))
        self.author_label.pack(side="left")
        self.homepage_label = ttk.Label(identity)
        self.homepage_label.pack(side="left", padx=(18, 4))
        self.homepage_link = tk.Label(
            identity, text=HOMEPAGE, fg="#0563c1", cursor="hand2",
            font=("Yu Gothic UI", 9, "underline"),
        )
        self.homepage_link.pack(side="left")
        self.homepage_link.bind("<Button-1>", lambda _event: webbrowser.open(HOMEPAGE))

        paths = ttk.Frame(frame)
        paths.pack(fill="x")
        self.input_label, self.input_browse = self._path_row(paths, 0, self.input_var, self._choose_input)
        self.output_label, self.output_browse = self._path_row(paths, 1, self.output_var, self._choose_output)
        paths.columnconfigure(1, weight=1)

        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=(14, 10))
        self.start_button = ttk.Button(buttons, command=self._start)
        self.start_button.pack(side="left")
        self.clear_button = ttk.Button(buttons, command=self._clear_log)
        self.clear_button.pack(side="left", padx=8)
        self.progress = ttk.Progressbar(buttons, mode="indeterminate", length=180)
        self.progress.pack(side="right")

        ttk.Label(frame, textvariable=self.status_var).pack(anchor="w", pady=(0, 6))
        log_frame = ttk.Frame(frame)
        log_frame.pack(fill="both", expand=True)
        self.log = tk.Text(log_frame, wrap="word", state="disabled", font=("Consolas", 10))
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        self.log.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    @staticmethod
    def _path_row(parent, row, variable, command):
        label = ttk.Label(parent, width=18)
        label.grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", padx=8, pady=4)
        button = ttk.Button(parent, command=command)
        button.grid(row=row, column=2, pady=4)
        return label, button

    def _set_language(self, _event=None):
        self.language = "ja" if self.language_var.get() == "日本語" else "en"
        s = TEXT[self.language]
        self.language_label.configure(text=s["language"])
        self.tagline_label.configure(text=s["tagline"])
        self.input_label.configure(text=s["input_folder"])
        self.output_label.configure(text=s["output_folder"])
        self.input_browse.configure(text=s["browse"])
        self.output_browse.configure(text=s["browse"])
        self.start_button.configure(text=s["start"])
        self.clear_button.configure(text=s["clear"])
        self.author_label.configure(text=s["author"])
        self.homepage_label.configure(text=s["homepage"])
        if str(self.start_button["state"]) != "disabled":
            self.status_var.set(s["ready"])

    def _choose_input(self):
        path = filedialog.askdirectory(title=TEXT[self.language]["choose_input"])
        if path:
            self.input_var.set(path)

    def _choose_output(self):
        path = filedialog.askdirectory(title=TEXT[self.language]["choose_output"])
        if path:
            self.output_var.set(path)

    def _append(self, text: str):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _clear_log(self):
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

    def _start(self):
        source = Path(self.input_var.get().strip())
        destination = Path(self.output_var.get().strip())
        s = TEXT[self.language]
        if not source.is_dir():
            messagebox.showerror(APP_TITLE, s["bad_input"])
            return
        if not self.output_var.get().strip():
            messagebox.showerror(APP_TITLE, s["bad_output"])
            return
        try:
            if source.resolve() == destination.resolve():
                messagebox.showerror(APP_TITLE, s["same_folder"])
                return
        except OSError:
            pass
        self.start_button.configure(state="disabled")
        self.progress.start(12)
        self.status_var.set(s["running"])
        self._append(f"{s['input_log']}: {source}")
        self._append(f"{s['output_log']}: {destination}")
        threading.Thread(target=self._worker, args=(source, destination, self.language), daemon=True).start()

    def _worker(self, source: Path, destination: Path, language: str):
        try:
            result = convert_folder(source, destination, lambda s: self.messages.put(("log", s)), TEXT[language])
            self.messages.put(("done", (result, language)))
        except Exception as exc:
            self.messages.put(("fatal", (str(exc), traceback.format_exc())))

    def _poll(self):
        try:
            while True:
                kind, payload = self.messages.get_nowait()
                if kind == "log":
                    self._append(str(payload))
                elif kind == "done":
                    (converted, failed), language = payload
                    s = TEXT[language]
                    self._finish()
                    self.status_var.set(s["done_status"].format(ok=converted, failed=failed))
                    messagebox.showinfo(APP_TITLE, s["done_dialog"].format(ok=converted, failed=failed))
                elif kind == "fatal":
                    message, details = payload
                    self._append(details)
                    self._finish()
                    self.status_var.set(TEXT[self.language]["failed_status"])
                    messagebox.showerror(APP_TITLE, message)
        except queue.Empty:
            pass
        self.root.after(100, self._poll)

    def _finish(self):
        self.progress.stop()
        self.start_button.configure(state="normal")


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista")
    except tk.TclError:
        pass
    RestoreApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
