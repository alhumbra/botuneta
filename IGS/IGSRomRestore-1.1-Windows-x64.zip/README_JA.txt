IGS ROM Restore 1.1
===================

作者: alhumbra
ホームページ: https://github.com/alhumbra/botuneta

概要
----
IGS Classic Arcade Collection由来の独自コンテナを通常ZIPへ復元し、
また既に通常ZIP化されたPGMセットのmaincpuを解析済みの逆変換で
復元するWindows用コマンドラインツールです。

ROM、BIOS、鍵ファイルは同梱していません。
必ず利用者自身が合法的に保有するデータだけを使用してください。

使い方
------
通常はIGSRomRestoreGUI.exeを起動してください。

GUI版:
  1. 既定表示は英語です。右上のLanguageから「日本語」へ切り替えられます。
  2. 「ROM入力フォルダー」の［参照...］からROMが入ったフォルダーを選択します。
  3. 「出力フォルダー」の［参照...］から別の出力先を選択します。
  4. ［変換開始］を押します。

ROMファイル名と内容から処理を自動判定します。対応していないZIPはスキップされ、
処理結果は画面のログと出力先のconversion-report.jsonへ記録されます。
入力と出力に同じフォルダーは指定できません。

コマンドライン版はIGSRomRestore.exeをコマンドプロンプトまたはPowerShellで実行します。

独自コンテナの復元:
  IGSRomRestore.exe dmnfrnt.zip dmnfrnt-restored.zip --dll IGSPlayLib2.dll
  IGSRomRestore.exe theglad.zip theglad-restored.zip --dll IGSPlayLib2.dll

解析済みPGM maincpuを復元:
  IGSRomRestore.exe cryptrom reference-free-maincpu --reference-free-pgm

--reference-free-pgmはkovsh、kovplus、orlegend、martmast、kov2pに対応します。
DLL互換Blowfish逆変換と小さな実行時注入巻き戻しだけを使います。
kov2pはM204版なのでkov2p204.zipとして出力します。
maincpu以外は入力どおり保持するsplit ZIPであり、不足ROMやBIOSは生成しません。

Python版（Windows / Linux / macOS）
----------------------------------
本パッケージのSOURCE/dmnfrnt_restore.pyは、Windows専用EXEを使わずに
Pythonから直接実行できます。LinuxおよびmacOSでも利用できます。

必要環境:
  Python 3.10以降（3.12推奨）
  PyCryptodome

依存ライブラリのインストール:
  Windows:
    py -m pip install pycryptodome

  Linux / macOS:
    python3 -m pip install pycryptodome

独自コンテナの復元:
  Windows:
    py SOURCE\dmnfrnt_restore.py dmnfrnt.zip dmnfrnt-restored.zip

  Linux / macOS:
    python3 SOURCE/dmnfrnt_restore.py dmnfrnt.zip dmnfrnt-restored.zip

PGM maincpu復元:
  Windows:
    py SOURCE\dmnfrnt_restore.py cryptrom reference-free-maincpu --reference-free-pgm

  Linux / macOS:
    python3 SOURCE/dmnfrnt_restore.py cryptrom reference-free-maincpu --reference-free-pgm

任意でDLLテーブルを照合する場合:
  python3 SOURCE/dmnfrnt_restore.py dmnfrnt.zip dmnfrnt-restored.zip --dll IGSPlayLib2.dll

--dllは検証用の任意指定です。通常は組み込みテーブルを使用するため省略できます。
パス処理にはPython標準のpathlibを使用しており、各OSの通常のパス形式を利用できます。

配布・ライセンス上の重要事項
----------------------------
本ツールのPGM逆変換処理はFBNeoのソースコードを基礎にしています。
FBNeoのカスタムライセンスにより、商用販売、貸与、収益化、寄付募集などは
認められていません。また、改変したソースコードの公開とライセンス全文の
同梱が必要です。詳細はLICENSE_FBNEO.txtを必ず確認してください。

本パッケージには対応するソースコードをSOURCE/dmnfrnt_restore.pyとして
同梱しています。GUIソースはSOURCE/igs_rom_restore_gui.pyです。
第三者ライブラリについてはTHIRD_PARTY_NOTICES.txtおよび
LICENSESフォルダーを参照してください。

無保証
------
本ソフトウェアは現状有姿で提供されます。データ損失等を避けるため、必ず元の
ROMファイルを保管し、別の出力フォルダーを指定してください。
