IGS ROM Restore 1.0
===================

概要
----
IGS Classic Arcade Collection由来の独自コンテナを通常ZIPへ復元し、
また既に通常ZIP化されたPGMセットのmaincpuを正規ダンプ参照セットに
合わせて正規化するWindows用コマンドラインツールです。

ROM、BIOS、鍵ファイル、正規参照ROMは同梱していません。
必ず利用者自身が合法的に保有するデータだけを使用してください。

使い方
------
コマンドプロンプトまたはPowerShellで実行します。

独自コンテナの復元:
  IGSRomRestore.exe dmnfrnt.zip dmnfrnt-restored.zip --dll IGSPlayLib2.dll
  IGSRomRestore.exe theglad.zip theglad-restored.zip --dll IGSPlayLib2.dll

PGM maincpuの一括正規化:
  IGSRomRestore.exe cryptrom normalized-maincpu --reference-dir decryptrom

対応maincpuプロファイル:
  kovsh, kovplus, kov2, kov2p, orlegend, oldsplus, martmast

正規化ではmaincpu以外の入力ZIPメンバーを保持し、既知のプログラムROMだけを
参照ZIPの正規ファイルへ置換します。kov2は参照側の新しいv107/v102版へ更新します。
処理結果とCRC32はmaincpu-normalization-report.jsonへ記録されます。

配布・ライセンス上の重要事項
----------------------------
本ツールのPGM逆変換処理はFBNeoのソースコードを基礎にしています。
FBNeoのカスタムライセンスにより、商用販売、貸与、収益化、寄付募集などは
認められていません。また、改変したソースコードの公開とライセンス全文の
同梱が必要です。詳細はLICENSE_FBNEO.txtを必ず確認してください。

本パッケージには対応するソースコードをSOURCE/dmnfrnt_restore.pyとして
同梱しています。第三者ライブラリについてはTHIRD_PARTY_NOTICES.txtおよび
LICENSESフォルダーを参照してください。

無保証
------
本ソフトウェアは現状有姿で提供されます。データ損失等を避けるため、必ず元の
ROMファイルを保管し、別の出力フォルダーを指定してください。

