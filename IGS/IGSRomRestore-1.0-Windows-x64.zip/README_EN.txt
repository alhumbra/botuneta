IGS ROM Restore 1.0
===================

Overview
--------
This Windows command-line tool restores supported proprietary IGS Classic
Arcade Collection containers to ordinary ZIP files. It can also normalize the
maincpu members of already-extracted PGM ZIP sets against a proper-dump
reference set.

No ROM, BIOS, key, or reference-ROM data is included. Use only data that you
are legally entitled to possess and process.

Usage
-----
Run from Command Prompt or PowerShell.

Restore a proprietary container:
  IGSRomRestore.exe dmnfrnt.zip dmnfrnt-restored.zip --dll IGSPlayLib2.dll
  IGSRomRestore.exe theglad.zip theglad-restored.zip --dll IGSPlayLib2.dll

Batch-normalize PGM maincpu files:
  IGSRomRestore.exe cryptrom normalized-maincpu --reference-dir decryptrom

Supported maincpu profiles:
  kovsh, kovplus, kov2, kov2p, orlegend, oldsplus, martmast

Normalization uses each reference ZIP as the canonical set definition. Data
with matching size and CRC32 is reused from the source and renamed; missing,
revision-mismatched, and maincpu members are supplied by the reference. Output
is a canonical non-merged set including BIOS members. For kov2, the reference
v107/v102 program revision is used. Member origins and CRC32 values are recorded
in maincpu-normalization-report.json.

Python version (Windows / Linux / macOS)
----------------------------------------
SOURCE/dmnfrnt_restore.py can be run directly without the Windows-only EXE.
The Python version also supports Linux and macOS.

Requirements:
  Python 3.10 or later (3.12 recommended)
  PyCryptodome

Install the dependency:
  Windows:
    py -m pip install pycryptodome

  Linux / macOS:
    python3 -m pip install pycryptodome

Restore a proprietary container:
  Windows:
    py SOURCE\dmnfrnt_restore.py dmnfrnt.zip dmnfrnt-restored.zip

  Linux / macOS:
    python3 SOURCE/dmnfrnt_restore.py dmnfrnt.zip dmnfrnt-restored.zip

Batch-normalize PGM maincpu files:
  Windows:
    py SOURCE\dmnfrnt_restore.py cryptrom normalized-maincpu --reference-dir decryptrom

  Linux / macOS:
    python3 SOURCE/dmnfrnt_restore.py cryptrom normalized-maincpu --reference-dir decryptrom

Optional DLL table cross-check:
  python3 SOURCE/dmnfrnt_restore.py dmnfrnt.zip dmnfrnt-restored.zip --dll IGSPlayLib2.dll

--dll is optional and is intended for verification. Embedded tables are used
when it is omitted. Paths are handled with Python's standard pathlib, so normal
path syntax for each operating system can be used.

Distribution and licensing notice
---------------------------------
The PGM reverse transformations in this tool are based on FBNeo source code.
The FBNeo custom license prohibits commercial sale, rental, monetization, and
donation solicitation. It also requires publication of modified source and
verbatim inclusion of its full license. Read LICENSE_FBNEO.txt before use or
redistribution.

Corresponding source is included as SOURCE/dmnfrnt_restore.py. See
THIRD_PARTY_NOTICES.txt and the LICENSES directory for bundled dependencies.

No warranty
-----------
This software is supplied as-is. Keep your original ROM files and always use a
separate output directory to avoid accidental data loss.
