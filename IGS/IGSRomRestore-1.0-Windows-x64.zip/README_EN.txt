IGS ROM Restore 1.0
===================

Overview
--------
This Windows command-line tool restores supported proprietary IGS Classic
Arcade Collection containers to ordinary ZIP files. It can also normalize the
maincpu members of already-extracted PGM ZIP sets using analyzed inverse
transformations.

No ROM, BIOS, or key data is included. Use only data that you
are legally entitled to possess and process.

Usage
-----
Run from Command Prompt or PowerShell.

Restore a proprietary container:
  IGSRomRestore.exe dmnfrnt.zip dmnfrnt-restored.zip --dll IGSPlayLib2.dll
  IGSRomRestore.exe theglad.zip theglad-restored.zip --dll IGSPlayLib2.dll

Restore analyzed PGM maincpu files:
  IGSRomRestore.exe cryptrom reference-free-maincpu --reference-free-pgm

--reference-free-pgm supports kovsh, kovplus, orlegend, martmast, and kov2p.
It uses DLL-compatible Blowfish inversion plus small runtime-injection undo
profiles. The kov2p input is M204 and
is emitted as kov2p204.zip. Non-maincpu members are preserved as a split ZIP;
missing ROMs and BIOS files are not synthesized.

Python version (Windows / Linux / macOS)
----------------------------------------
SOURCE/dmnfrnt_restore.py can be run directly without the Windows-only EXE.
The Python version also supports Linux and macOS.

Requirements:
  Python 3.10 or later (3.12 recommended)
  PyCryptodome

Install the dependency:
  Windows:
    py -m pip install pycryptodome

  Linux / macOS:
    python3 -m pip install pycryptodome

Restore a proprietary container:
  Windows:
    py SOURCE\dmnfrnt_restore.py dmnfrnt.zip dmnfrnt-restored.zip

  Linux / macOS:
    python3 SOURCE/dmnfrnt_restore.py dmnfrnt.zip dmnfrnt-restored.zip

Reference-free PGM maincpu restoration:
  Windows:
    py SOURCE\dmnfrnt_restore.py cryptrom reference-free-maincpu --reference-free-pgm

  Linux / macOS:
    python3 SOURCE/dmnfrnt_restore.py cryptrom reference-free-maincpu --reference-free-pgm

Optional DLL table cross-check:
  python3 SOURCE/dmnfrnt_restore.py dmnfrnt.zip dmnfrnt-restored.zip --dll IGSPlayLib2.dll

--dll is optional and is intended for verification. Embedded tables are used
when it is omitted. Paths are handled with Python's standard pathlib, so normal
path syntax for each operating system can be used.

Distribution and licensing notice
---------------------------------
The PGM reverse transformations in this tool are based on FBNeo source code.
The FBNeo custom license prohibits commercial sale, rental, monetization, and
donation solicitation. It also requires publication of modified source and
verbatim inclusion of its full license. Read LICENSE_FBNEO.txt before use or
redistribution.

Corresponding source is included as SOURCE/dmnfrnt_restore.py. See
THIRD_PARTY_NOTICES.txt and the LICENSES directory for bundled dependencies.

No warranty
-----------
This software is supplied as-is. Keep your original ROM files and always use a
separate output directory to avoid accidental data loss.
