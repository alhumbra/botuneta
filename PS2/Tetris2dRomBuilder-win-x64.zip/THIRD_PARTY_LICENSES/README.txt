THIRD-PARTY COMPONENTS
======================

This is a framework-dependent Windows build targeting .NET 8. It does not
bundle the complete Microsoft .NET Runtime or Windows Desktop Runtime. A small
.NET application host is included, while the runtime is installed separately
by the end user.

The supplied .NET license and notice files document the applicable Microsoft
redistributable code and the runtime required to execute the application.

Included notices
----------------
DOTNET-LIBRARY-LICENSE.txt
  Microsoft license terms applicable to Windows .NET product distributions and
  redistributable code.

DOTNET-RUNTIME-MIT-LICENSE.txt
  MIT license shipped with Microsoft.NETCore.App.Runtime.win-x64 8.0.30.

DOTNET-WINDOWSDESKTOP-MIT-LICENSE.txt
  MIT license shipped with Microsoft.WindowsDesktop.App.Runtime.win-x64 8.0.30.

DOTNET-RUNTIME-THIRD-PARTY-NOTICES.txt
  Third-party notices shipped with Microsoft.NETCore.App.Runtime.win-x64 8.0.30.

Official license information:
https://github.com/dotnet/core/blob/main/license-information.md
https://dotnet.microsoft.com/en-us/dotnet_library_license.htm

These components are not covered by the Tetris2d ROM Builder project license.
