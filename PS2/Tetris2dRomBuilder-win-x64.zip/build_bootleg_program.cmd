@echo off
setlocal

set "INPUT_DIR=%~1"
if "%INPUT_DIR%"=="" set "INPUT_DIR=%CD%"

set "OUTPUT_DIR=%~2"
if "%OUTPUT_DIR%"=="" set "OUTPUT_DIR=%CD%\bootleg_program"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_bootleg_program.ps1" -InputFolder "%INPUT_DIR%" -OutputFolder "%OUTPUT_DIR%"
if errorlevel 1 (
    echo.
    echo Conversion failed.
    exit /b 1
)

echo.
echo Completed successfully.
echo Output: %OUTPUT_DIR%
exit /b 0
