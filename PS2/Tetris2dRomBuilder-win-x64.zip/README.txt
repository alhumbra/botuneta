Tetris2d ROM Builder
====================

PS2版「Sega Ages 2500 Series Vol.28 Tetris Collection」の抽出ファイルから、
MAME/FBNeo準拠の復号bootlegセット tetris2d.zip だけを作成する専用GUIです。

必要な入力
------------
tet_dec.p00   65,536 bytes  CRC32 01B02402
tetrisd.p94  131,072 bytes  CRC32 BA0B61B4
tetris.obj   131,072 bytes  CRC32 763A1D1B
tetris.scr   262,144 bytes  CRC32 C1E91127
tetris.snd    32,768 bytes  CRC32 BD9BA01B

任意（FBNeoの実行には不要）
--------------------------
315-5298.b9      235 bytes  CRC32 39B47212

必要ファイルは、すべて選択した入力フォルダーの直下に置いてください。
サブフォルダーおよびZIP内は検索しません。

使い方
------
1. Tetris2dRomBuilder.exeを起動します。
   起動時は英語表示です。右上の「Language / 言語」でEnglish／日本語を切り替えられます。
2. 入力フォルダーと出力フォルダーを選択します。
3. 「tetris2d.zipを作成」を押します。

315-5298.b9がなければ8ファイル、あれば9ファイルのZIPを作成します。
出力ZIP内の全ファイルはCRC検証されます。

bootlegプログラムの構成
-----------------------
bootleg_epr-12192.a5 = tet_dec.p00の偶数位置32KB
                     + tetrisd.p94偶数分割側の後半32KB
                     + 6バイト修正

bootleg_epr-12193.a7 = tet_dec.p00の奇数位置32KB
                     + tetrisd.p94奇数分割側の後半32KB
                     + 8バイト修正

tet_prg.p00は使用しません。tet_dec.p00とtet_prg.p00は連続した前半・後半ではないため、
copy /bで連結してからODD/EVEN分割すると後半32KBが不正になります。

対応環境
--------
Windows 64bitおよびMicrosoft .NET 8 Desktop Runtime（x64）が必要です。
この軽量版には.NETランタイムを同梱していません。Microsoft公式ページから
.NET 8 Desktop Runtime x64をインストールしてください。
https://dotnet.microsoft.com/en-us/download/dotnet/8.0

実行ファイルにはデジタル署名がないため、Windows SmartScreenが発行元不明の警告を
表示する場合があります。配布者が提示するアーカイブのハッシュ値を確認してください。

配布とライセンス
----------------
本ツールは非公式であり、セガ、M2、The Tetris Company、MAME、FinalBurn Neo、
Microsoftおよび各関係会社の承認・後援を受けたものではありません。

配布前にLICENSE.txt、LEGAL_NOTICE.txt、README_EN.txt、および
THIRD_PARTY_LICENSESフォルダー内の文書を確認してください。
本ツールのライセンスは、ゲームデータや生成されたROMへ権利を付与するものではありません。
