param(
    [Parameter(Mandatory = $true)][string]$InputFolder,
    [Parameter(Mandatory = $true)][string]$OutputFolder
)

$ErrorActionPreference = 'Stop'

function Get-Sha1([byte[]]$Data) {
    $sha1 = [Security.Cryptography.SHA1]::Create()
    try {
        return ([BitConverter]::ToString($sha1.ComputeHash($Data))).Replace('-', '').ToLowerInvariant()
    } finally {
        $sha1.Dispose()
    }
}

$decodedPath = Join-Path $InputFolder 'tet_dec.p00'
$programPath = Join-Path $InputFolder 'tetrisd.p94'
$decoded = [IO.File]::ReadAllBytes($decodedPath)
$program = [IO.File]::ReadAllBytes($programPath)

if ($decoded.Length -ne 0x10000) { throw 'tet_dec.p00 must be 65536 bytes.' }
if ($program.Length -ne 0x20000) { throw 'tetrisd.p94 must be 131072 bytes.' }
if ((Get-Sha1 $decoded) -ne '92e45e38e21291904f78e5909bd44f018a874cb4') { throw 'tet_dec.p00 CRC mismatch.' }
if ((Get-Sha1 $program) -ne 'da004f7f107af0423d6256a787cdbab8f46fef3a') { throw 'tetrisd.p94 CRC mismatch.' }

[byte[]]$rom92 = New-Object 'byte[]' 0x10000
[byte[]]$rom93 = New-Object 'byte[]' 0x10000
for ($i = 0; $i -lt 0x8000; $i++) {
    $rom92[$i] = $decoded[$i * 2]
    $rom93[$i] = $decoded[$i * 2 + 1]
    $rom92[0x8000 + $i] = $program[0x10000 + $i * 2]
    $rom93[0x8000 + $i] = $program[0x10000 + $i * 2 + 1]
}

$patch92 = @{ 0x01F8=0x55; 0x01F9=0xC8; 0x0203=0x00; 0x27B5=0xFF; 0x27B6=0xDC; 0x27B7=0x01 }
$patch93 = @{ 0x01F8=0x61; 0x01F9=0xBD; 0x0203=0x60; 0x1441=0x7F; 0x27B4=0x02; 0x27B5=0xFF; 0x27B6=0xFE; 0x27B7=0x98 }
foreach ($offset in $patch92.Keys) { $rom92[[int]$offset] = [byte]$patch92[$offset] }
foreach ($offset in $patch93.Keys) { $rom93[[int]$offset] = [byte]$patch93[$offset] }

if ((Get-Sha1 $rom92) -ne 'a590d695c7d802ad7afe77990dd15775c03c727a') { throw 'bootleg_epr-12192.a5 output CRC mismatch.' }
if ((Get-Sha1 $rom93) -ne '88aa9c7868b914e5cbd3fc0def5d61d5d5c37d21') { throw 'bootleg_epr-12193.a7 output CRC mismatch.' }

[IO.Directory]::CreateDirectory($OutputFolder) | Out-Null
[IO.File]::WriteAllBytes((Join-Path $OutputFolder 'bootleg_epr-12192.a5'), $rom92)
[IO.File]::WriteAllBytes((Join-Path $OutputFolder 'bootleg_epr-12193.a7'), $rom93)

Write-Host 'bootleg_epr-12192.a5 CRC 8FF44F5F'
Write-Host 'bootleg_epr-12193.a7 CRC E8C59F9D'
