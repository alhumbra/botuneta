Tetris2d ROM Builder
====================

Tetris2d ROM Builder creates the decrypted bootleg ROM set tetris2d.zip for
MAME/FinalBurn Neo from files extracted from the Japanese PlayStation 2 release
"Sega Ages 2500 Series Vol. 28: Tetris Collection."

The application is unofficial and does not include the required game data.

System requirements
-------------------
Windows 64-bit and Microsoft .NET 8 Desktop Runtime (x64).

This is the lightweight main distribution. The .NET runtime is not bundled.
Install the current .NET 8 Desktop Runtime x64 from Microsoft's official page:
https://dotnet.microsoft.com/en-us/download/dotnet/8.0

The executable is not digitally code-signed. Windows SmartScreen may therefore
show an unknown-publisher warning. Verify the archive hash supplied by the
distributor before running it.

Required input files
--------------------
Place these files directly in one folder:

  tet_dec.p00    65,536 bytes   CRC32 01B02402
  tetrisd.p94   131,072 bytes   CRC32 BA0B61B4
  tetris.obj    131,072 bytes   CRC32 763A1D1B
  tetris.scr    262,144 bytes   CRC32 C1E91127
  tetris.snd     32,768 bytes   CRC32 BD9BA01B

Optional input
--------------
  315-5298.b9       235 bytes   CRC32 39B47212

315-5298.b9 is not required to run the set in FinalBurn Neo. If it is absent,
the application creates an eight-file ZIP. If a valid copy is present directly
in the input folder, it is included as the ninth file. Supply it when a complete
MAME ROM audit requires the PLD entry.

The application searches only the selected folder itself. It does not search
subfolders and does not inspect existing ZIP archives for input files.

GUI instructions
----------------
1. Run Tetris2dRomBuilder.exe.
2. The default UI language is English. Use "Language / 言語" in the upper-right
   corner to switch between English and Japanese.
3. Select the input folder and output folder.
4. Click "Create tetris2d.zip."

Output
------
  bootleg_epr-12192.a5   65,536 bytes   CRC32 8FF44F5F
  bootleg_epr-12193.a7   65,536 bytes   CRC32 E8C59F9D
  epr-12165.b9           65,536 bytes   CRC32 62640221
  epr-12166.b10          65,536 bytes   CRC32 9ABD183B
  epr-12167.b11          65,536 bytes   CRC32 2495FD4E
  epr-12168.a7           32,768 bytes   CRC32 BD9BA01B
  mpr-12194.b1           65,536 bytes   CRC32 2FB38880
  mpr-12195.b5           65,536 bytes   CRC32 D6A02CBA
  315-5298.b9               235 bytes   CRC32 39B47212 (optional)

Every generated file is verified before the ZIP replaces an existing output.

Bootleg program reconstruction
------------------------------
bootleg_epr-12192.a5 is assembled from the even-position bytes in tet_dec.p00,
the final 32 KiB of the even lane from tetrisd.p94, and six byte corrections.

bootleg_epr-12193.a7 is assembled from the odd-position bytes in tet_dec.p00,
the final 32 KiB of the odd lane from tetrisd.p94, and eight byte corrections.

tet_prg.p00 is not used. It is not a contiguous second half of tet_dec.p00.

Command-line helper
-------------------
The included build_bootleg_program.cmd and build_bootleg_program.ps1 scripts
reconstruct only the two bootleg program ROM files. See CMD_RESTORE_GUIDE.txt
for the Japanese command-line explanation.

License and legal information
-----------------------------
Read LICENSE.txt, LEGAL_NOTICE.txt, and the files in THIRD_PARTY_LICENSES before
redistributing this package. The application license does not grant rights to
game data or generated ROM files.
